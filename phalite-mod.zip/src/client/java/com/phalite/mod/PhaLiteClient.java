package com.phalite.mod;

import com.phalite.mod.screen.PhaLiteConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class PhaLiteClient implements ClientModInitializer {

    // F11 пернесі (F3 сияқты debug пернелерімен тіркесу күрделі болғандықтан,
    // біз бөлек keybind қолданамыз — әдепкі: F8)
    private static KeyBinding openConfigKey;

    @Override
    public void onInitializeClient() {
        // Конфиг экранын ашатын пернені тіркеу
        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.phalite.open_config",       // translation key
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_F8,                // Әдепкі перне: F8
                "category.phalite"               // категория
        ));

        // Tick event — перне басылуын тексеру
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.wasPressed()) {
                if (client.currentScreen == null) {
                    // Тек main menu немесе in-game болса ашу
                    client.setScreen(new PhaLiteConfigScreen(client.currentScreen));
                }
            }
        });

        System.out.println("[PhaLite] Mod жүктелді! F8 — баптаулар экраны.");
    }
}
