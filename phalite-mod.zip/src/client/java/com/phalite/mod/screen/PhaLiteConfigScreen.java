package com.phalite.mod.screen;

import com.phalite.mod.config.PhaLiteConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class PhaLiteConfigScreen extends Screen {

    private final Screen parent;
    private TextFieldWidget ipField;
    private TextFieldWidget portField;

    public PhaLiteConfigScreen(Screen parent) {
        super(Text.literal("PhaLite — Сервер баптаулары"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // IP өрісі
        this.ipField = new TextFieldWidget(
                this.textRenderer,
                centerX - 150, centerY - 40,
                300, 20,
                Text.literal("Сервер IP")
        );
        this.ipField.setMaxLength(128);
        this.ipField.setText(PhaLiteConfig.getInstance().serverIp);
        this.ipField.setPlaceholder(Text.literal("мысалы: play.novacraft.kz"));
        this.addDrawableChild(this.ipField);

        // Порт өрісі
        this.portField = new TextFieldWidget(
                this.textRenderer,
                centerX - 150, centerY,
                300, 20,
                Text.literal("Порт")
        );
        this.portField.setMaxLength(5);
        this.portField.setText(String.valueOf(PhaLiteConfig.getInstance().serverPort));
        this.portField.setPlaceholder(Text.literal("25565"));
        this.addDrawableChild(this.portField);

        // Сақтау батырмасы
        this.addDrawableChild(ButtonWidget.builder(Text.literal("✔ Сақтау"), btn -> {
            saveConfig();
            this.client.setScreen(parent);
        }).dimensions(centerX - 155, centerY + 35, 148, 20).build());

        // Бас тарту батырмасы
        this.addDrawableChild(ButtonWidget.builder(Text.literal("✖ Бас тарту"), btn -> {
            this.client.setScreen(parent);
        }).dimensions(centerX + 7, centerY + 35, 148, 20).build());

        // Фокусты IP өрісіне қою
        this.setInitialFocus(this.ipField);
    }

    private void saveConfig() {
        PhaLiteConfig config = PhaLiteConfig.getInstance();
        config.serverIp = this.ipField.getText().trim();

        try {
            int port = Integer.parseInt(this.portField.getText().trim());
            if (port > 0 && port <= 65535) {
                config.serverPort = port;
            }
        } catch (NumberFormatException e) {
            config.serverPort = 25565;
        }

        config.save();
        System.out.println("[PhaLite] Конфиг сақталды: " + config.getFullAddress());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Фон
        this.renderBackground(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        // Тақырып
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("§6§lPhaLite §r§7— Сервер баптаулары"),
                centerX, centerY - 80, 0xFFFFFF
        );

        // IP жазуы
        context.drawTextWithShadow(
                this.textRenderer,
                Text.literal("§bСервер IP мекенжайы:"),
                centerX - 150, centerY - 55, 0xFFFFFF
        );

        // Порт жазуы
        context.drawTextWithShadow(
                this.textRenderer,
                Text.literal("§bПорт §7(әдепкі: 25565):"),
                centerX - 150, centerY - 15, 0xFFFFFF
        );

        // Ағымдағы сақталған IP
        String saved = PhaLiteConfig.getInstance().getFullAddress();
        String savedText = saved.isEmpty() ? "§cСақталмаған" : "§a" + saved;
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("§7Ағымдағы: " + savedText),
                centerX, centerY + 65, 0xAAAAAA
        );

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // Enter басса — сақтау
        if (keyCode == 257 || keyCode == 335) {
            saveConfig();
            this.client.setScreen(parent);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
