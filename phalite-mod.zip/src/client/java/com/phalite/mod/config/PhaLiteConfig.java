package com.phalite.mod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class PhaLiteConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("phalite.json");

    private static PhaLiteConfig instance;

    // Конфиг мәндері
    public String serverIp = "";
    public int serverPort = 25565;

    public static PhaLiteConfig getInstance() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public static PhaLiteConfig load() {
        if (CONFIG_PATH.toFile().exists()) {
            try (Reader reader = new FileReader(CONFIG_PATH.toFile())) {
                instance = GSON.fromJson(reader, PhaLiteConfig.class);
                if (instance == null) instance = new PhaLiteConfig();
                return instance;
            } catch (IOException e) {
                System.err.println("[PhaLite] Config оқу қатесі: " + e.getMessage());
            }
        }
        instance = new PhaLiteConfig();
        instance.save();
        return instance;
    }

    public void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            System.err.println("[PhaLite] Config сақтау қатесі: " + e.getMessage());
        }
    }

    public String getFullAddress() {
        if (serverIp == null || serverIp.isEmpty()) return "";
        if (serverPort != 25565) return serverIp + ":" + serverPort;
        return serverIp;
    }
}
