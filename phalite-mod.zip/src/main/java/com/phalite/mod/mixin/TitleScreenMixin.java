package com.phalite.mod.mixin;

import com.phalite.mod.config.PhaLiteConfig;
import com.phalite.mod.screen.PhaLiteConfigScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

    protected TitleScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void phalite$addButton(CallbackInfo ci) {
        // Minecraft 1.21.4 TitleScreen-дегі стандартты батырма позициялары:
        //   int i = this.height / 4 + 48;
        //   Singleplayer: x = width/2-100, y = i,      w=200, h=20
        //   Multiplayer:  x = width/2-100, y = i+24,   w=200, h=20
        //   Realms:       x = width/2-100, y = i+48,   w=200, h=20
        //   Options(кіші батырмалар): y = i+72

        int i = this.height / 4 + 48;
        int centerX = this.width / 2;

        // Realms батырмасын (i+48) → (i+72)-ге жылжыту
        // Options/Language батырмаларын (i+72) → (i+96)-ге жылжыту
        for (ClickableWidget widget : this.children().stream()
                .filter(c -> c instanceof ClickableWidget)
                .map(c -> (ClickableWidget) c)
                .toList()) {

            int wy = widget.getY();

            // Realms батырмасы (i+48) → i+72
            if (wy == i + 48) {
                widget.setY(i + 72);
            }
            // Language/Options/Quit батырмалары (i+72) → i+96
            else if (wy == i + 72) {
                widget.setY(i + 96);
            }
        }

        // PhaLite батырмасын Multiplayer (i+24) астына қою: y = i+48
        ButtonWidget phaliteButton = ButtonWidget.builder(
                Text.literal("§6⚡ §lPhaLite"),
                btn -> phalite$connectToServer()
        ).dimensions(centerX - 100, i + 48, 200, 20).build();

        this.addDrawableChild(phaliteButton);
    }

    private void phalite$connectToServer() {
        PhaLiteConfig config = PhaLiteConfig.getInstance();

        // Егер IP бос болса — конфиг экранына апару
        if (config.serverIp == null || config.serverIp.isEmpty()) {
            this.client.setScreen(new PhaLiteConfigScreen(this));
            return;
        }

        // Серверге тікелей қосылу
        String address = config.getFullAddress();
        ServerAddress serverAddress = ServerAddress.parse(address);
        ServerInfo serverInfo = new ServerInfo("PhaLite", address, ServerInfo.ServerType.OTHER);

        ConnectScreen.connect(
                this,
                this.client,
                serverAddress,
                serverInfo,
                false,
                null
        );
    }
}
