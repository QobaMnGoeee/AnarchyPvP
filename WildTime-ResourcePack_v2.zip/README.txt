WildTime ▪ resource pack (scoreboard/TAB frames + custom DeluxeMenus GUI)
Glyphs live in the DEFAULT font (private-use characters):
  U+E000  space  -2 px   (puts the frame flush with the board's left edge)
  U+E001  space  9 px   (indent for the other lines)
  U+E010..U+E019  frame for 6..15 scoreboard lines  (height = 9*lines + 10 px)
Table: n -> char:  6=U+E010(64px), 7=U+E011(73px), 8=U+E012(82px), 9=U+E013(91px), 10=U+E014(100px), 11=U+E015(109px), 12=U+E016(118px), 13=U+E017(127px), 14=U+E018(136px), 15=U+E019(145px)
TAB list (player list), frame on BOTH sides: U+E100..U+E113 = left frame, U+E200..U+E213 = right (mirrored) frame, 1..20 rows
  (header 6 lines, footer 4 lines, panel width 260 px); U+E003 space 241 px, U+E004 -1 px, U+E005 11 px, U+E006 -2 px
