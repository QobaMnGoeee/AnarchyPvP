WildTime ▪ scoreboard frame  (resource pack)
Glyphs live in the DEFAULT font (private-use characters):
  U+E000  space  -2 px   (puts the frame flush with the board's left edge)
  U+E001  space  9 px   (indent for the other lines)
  U+E010..U+E019  frame for 6..15 scoreboard lines  (height = 9*lines + 10 px)
Table: n -> char:  6=U+E010(64px), 7=U+E011(73px), 8=U+E012(82px), 9=U+E013(91px), 10=U+E014(100px), 11=U+E015(109px), 12=U+E016(118px), 13=U+E017(127px), 14=U+E018(136px), 15=U+E019(145px)
