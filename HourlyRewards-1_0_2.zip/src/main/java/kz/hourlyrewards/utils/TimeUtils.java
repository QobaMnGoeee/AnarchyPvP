package kz.hourlyrewards.utils;

public class TimeUtils {

    public static String formatTime(long seconds) {
        if (seconds < 3600) {
            return (seconds / 60) + " минут";
        } else {
            long hours = seconds / 3600;
            long mins = (seconds % 3600) / 60;
            return mins > 0 ? hours + " сағат " + mins + " минут" : hours + " сағат";
        }
    }
}