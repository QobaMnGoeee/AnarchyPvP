package kz.hourlyrewards.models;

public enum TaskState {
    LOCKED,
    OPEN,
    READY,
    CLAIMED
}