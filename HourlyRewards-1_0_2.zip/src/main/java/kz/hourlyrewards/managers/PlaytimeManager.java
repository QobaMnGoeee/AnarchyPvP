package kz.hourlyrewards.managers;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.data.Settings;
import kz.hourlyrewards.models.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class PlaytimeManager {

    private final HourlyRewards plugin;
    private BukkitTask playtimeTask;
    private BukkitTask afkCheckTask;

    public PlaytimeManager(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long playtimeInterval = Settings.PLAYTIME_TICK_SECONDS * 20L;

        playtimeTask = new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
                    if (data == null) continue;
                    if (!data.isAfk()) {
                        data.addPlaytimeSeconds(Settings.PLAYTIME_TICK_SECONDS);
                    }
                    plugin.getTaskManager().checkAndUpdate(player);
                }
            }
        }.runTaskTimer(plugin, playtimeInterval, playtimeInterval);

        long afkTimeout = Settings.AFK_TIMEOUT_SECONDS * 1000L;

        afkCheckTask = new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                for (Player player : Bukkit.getOnlinePlayers()) {
                    PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
                    if (data == null) continue;
                    boolean isAfk = (now - data.getLastMoveTime()) > afkTimeout;
                    data.setAfk(isAfk);
                }
            }
        }.runTaskTimer(plugin, Settings.AFK_CHECK_TICKS, Settings.AFK_CHECK_TICKS);
    }

    public void stop() {
        if (playtimeTask != null) playtimeTask.cancel();
        if (afkCheckTask != null) afkCheckTask.cancel();
    }
}