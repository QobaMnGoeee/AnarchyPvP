package kz.hourlyrewards.managers;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.data.Messages;
import kz.hourlyrewards.data.TaskInfo;
import kz.hourlyrewards.data.TaskRegistry;
import kz.hourlyrewards.models.PlayerData;
import kz.hourlyrewards.models.TaskState;
import kz.hourlyrewards.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class TaskManager {

    private final HourlyRewards plugin;

    public TaskManager(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    public void checkAndUpdate(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
        if (data == null) return;

        for (int i = 1; i <= TaskRegistry.size(); i++) {
            TaskState current = data.getTaskState(i);
            if (current != TaskState.OPEN) continue;

            long required = getRequiredSeconds(i);
            if (data.getPlaytimeSeconds() >= required) {
                data.setTaskState(i, TaskState.READY);
                plugin.getPlayerDataManager().savePlayer(player.getUniqueId());
                notifyPlayer(player, i);
            }
        }
    }

    public void giveReward(Player player, int taskId) {
        PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
        if (data == null) return;

        String cmd = getRewardCommand(taskId);
        if (cmd == null || cmd.isEmpty()) {
            plugin.getLogger().warning("[HourlyRewards] ЕСКЕРТУ: команда орындалмады, task_" + taskId);
            return;
        }

        String finalCmd = cmd.replace("%player%", player.getName());
        try {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCmd);
        } catch (Exception e) {
            plugin.getLogger().warning("[HourlyRewards] ЕСКЕРТУ: команда орындалмады: " + finalCmd);
        }

        data.setTaskState(taskId, TaskState.CLAIMED);

        if (taskId < TaskRegistry.size()) {
            TaskState nextState = data.getTaskState(taskId + 1);
            if (nextState == TaskState.LOCKED) {
                data.setTaskState(taskId + 1, TaskState.OPEN);
            }
        }

        plugin.getPlayerDataManager().savePlayer(player.getUniqueId());

        String prize = getPrizeDisplay(taskId);
        player.sendMessage(ColorUtils.color(Messages.rewardClaimed(prize)));

        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0);
    }

    private void notifyPlayer(Player player, int taskId) {
        player.sendMessage(ColorUtils.color(Messages.taskReady(taskId)));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.0f);
    }

    public long getRequiredSeconds(int taskId) {
        return TaskRegistry.get(taskId).getRequiredSeconds();
    }

    public String getRewardCommand(int taskId) {
        return TaskRegistry.get(taskId).getRewardCommand();
    }

    public String getPrizeDisplay(int taskId) {
        return TaskRegistry.get(taskId).getPrizeDisplay();
    }

    public String getDisplayTime(int taskId) {
        return TaskRegistry.get(taskId).getDisplayTime();
    }

    public int getSlot(int taskId) {
        return TaskRegistry.get(taskId).getSlot();
    }

    public TaskInfo getTaskInfo(int taskId) {
        return TaskRegistry.get(taskId);
    }
}
