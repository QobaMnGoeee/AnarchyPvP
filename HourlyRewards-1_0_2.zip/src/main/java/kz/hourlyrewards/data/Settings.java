package kz.hourlyrewards.data;

public class Settings {

    public static final long AFK_TIMEOUT_SECONDS = 300L;

    public static final long PLAYTIME_TICK_SECONDS = 60L;

    public static final long AFK_CHECK_TICKS = 600L;

    private Settings() {
    }
}
