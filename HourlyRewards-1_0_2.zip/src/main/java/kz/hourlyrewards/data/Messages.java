package kz.hourlyrewards.data;

public class Messages {

    public static final String PREFIX = "§8[§a§lСыйлықтар§8] §f";

    public static String taskReady(int taskId) {
        return PREFIX + "§a" + taskId + "-тапсырма орындалды! §6/free §fжазып алыңыз!";
    }

    public static String rewardClaimed(String prize) {
        return PREFIX + "§a✔ §f" + prize + " сыйлығы алынды!";
    }

    public static String alreadyClaimed() {
        return PREFIX + "§cБұл сыйлықты алдыңыз!";
    }

    public static String taskLocked() {
        return PREFIX + "§cАлдымен алдыңғы тапсырманы орындаңыз!";
    }

    public static String notReady(String current, String required) {
        return PREFIX + "§eТапсырма орындалмаған! Уақытыңыз: §f" + current + "§e / §f" + required;
    }

    public static String noPermission() {
        return "§cСізде рұқсат жоқ!";
    }

    public static String playersOnly() {
        return "§cБұл команда тек ойыншылар үшін!";
    }
}
