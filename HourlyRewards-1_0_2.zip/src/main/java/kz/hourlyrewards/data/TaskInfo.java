package kz.hourlyrewards.data;

public class TaskInfo {

    private final int id;
    private final int slot;
    private final long requiredSeconds;
    private final String displayTime;
    private final String prizeDisplay;
    private final String rewardCommand;

    public TaskInfo(int id, int slot, long requiredSeconds, String displayTime, String prizeDisplay, String rewardCommand) {
        this.id = id;
        this.slot = slot;
        this.requiredSeconds = requiredSeconds;
        this.displayTime = displayTime;
        this.prizeDisplay = prizeDisplay;
        this.rewardCommand = rewardCommand;
    }

    public int getId() {
        return id;
    }

    public int getSlot() {
        return slot;
    }

    public long getRequiredSeconds() {
        return requiredSeconds;
    }

    public String getDisplayTime() {
        return displayTime;
    }

    public String getPrizeDisplay() {
        return prizeDisplay;
    }

    public String getRewardCommand() {
        return rewardCommand;
    }
}
