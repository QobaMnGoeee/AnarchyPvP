package kz.hourlyrewards.data;

import java.util.List;

public class TaskRegistry {

    private static final List<TaskInfo> TASKS = List.of(
            new TaskInfo(1, 20, 1800L, "30 минут", "3,500₸", "eco give %player% 3500"),
            new TaskInfo(2, 21, 7200L, "2 сағат", "8,000₸", "eco give %player% 8000"),
            new TaskInfo(3, 22, 21600L, "6 сағат", "15,000₸", "eco give %player% 15000"),
            new TaskInfo(4, 23, 36000L, "10 сағат", "30,000₸", "eco give %player% 30000"),
            new TaskInfo(5, 24, 54000L, "15 сағат", "60,000₸", "eco give %player% 60000"),
            new TaskInfo(6, 29, 90000L, "25 сағат", "170,000₸", "eco give %player% 170000"),
            new TaskInfo(7, 30, 180000L, "50 сағат", "400,000₸", "eco give %player% 400000"),
            new TaskInfo(8, 31, 234000L, "65 сағат", "650,000₸", "eco give %player% 650000"),
            new TaskInfo(9, 32, 252000L, "70 сағат", "800,000₸", "eco give %player% 800000"),
            new TaskInfo(10, 33, 360000L, "100 сағат", "✦ 1 Донат Кейс ✦", "dc givekey %player% default 1")
    );

    public static TaskInfo get(int taskId) {
        if (taskId < 1 || taskId > TASKS.size()) {
            throw new IllegalArgumentException("Тапсырма нөмірі дұрыс емес: " + taskId);
        }
        return TASKS.get(taskId - 1);
    }

    public static int size() {
        return TASKS.size();
    }

    public static List<TaskInfo> all() {
        return TASKS;
    }

    private TaskRegistry() {
    }
}
