package kz.hourlyrewards.data;

public class SkullTextures {

    public static final String GREEN = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2M5ZTdmMDlhZTEwZjFhMzFhNGEwNGZlZDU1YWZiNWRkZWU2YzM2YzQ4NmZiMjMzZTNmOGRmMmYwY2Q0MzI1ZiJ9fX0=";

    public static final String RED = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYjc1OTc0MzY0ZjJjYzg0MzEyOTRmNWRhOTg5OGNkN2JlYWY2ZGVmNDZiNDU4MWMyNzM2YTE5OTU4MjA2NjZmYiJ9fX0=";

    private SkullTextures() {
    }
}
