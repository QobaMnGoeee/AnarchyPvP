package kz.hourlyrewards.data;

import org.bukkit.Material;

public class GuiSettings {

    public static final String TITLE = "§8Сыйлықтар";

    public static final Material BORDER_MATERIAL = Material.PURPLE_STAINED_GLASS_PANE;

    public static final int SIZE = 54;

    private GuiSettings() {
    }
}
