package kz.hourlyrewards.commands;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.data.Messages;
import kz.hourlyrewards.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreeCommand implements CommandExecutor {

    private final HourlyRewards plugin;

    public FreeCommand(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtils.color(Messages.playersOnly()));
            return true;
        }

        if (!player.hasPermission("hourlyrewards.use")) {
            player.sendMessage(ColorUtils.color(Messages.noPermission()));
            return true;
        }

        plugin.getRewardsGUI().open(player);
        return true;
    }
}