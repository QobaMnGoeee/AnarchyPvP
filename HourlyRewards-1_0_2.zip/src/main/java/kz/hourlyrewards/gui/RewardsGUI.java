package kz.hourlyrewards.gui;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.data.GuiSettings;
import kz.hourlyrewards.data.SkullTextures;
import kz.hourlyrewards.models.PlayerData;
import kz.hourlyrewards.models.TaskState;
import kz.hourlyrewards.utils.ColorUtils;
import kz.hourlyrewards.utils.SkullBuilder;
import kz.hourlyrewards.utils.TimeUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

public class RewardsGUI {

    private final HourlyRewards plugin;

    private static final int[] BORDER_SLOTS = {
        0,1,2,3,4,5,6,7,8,
        9,17,
        18,26,
        27,35,
        36,44,
        45,46,47,48,49,50,51,52,53
    };

    public RewardsGUI(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, GuiSettings.SIZE, ColorUtils.color(GuiSettings.TITLE));

        String greenTexture = SkullTextures.GREEN;
        String redTexture = SkullTextures.RED;

        ItemStack border = new ItemStack(GuiSettings.BORDER_MATERIAL);
        ItemMeta borderMeta = border.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            border.setItemMeta(borderMeta);
        }

        for (int slot : BORDER_SLOTS) {
            inv.setItem(slot, border);
        }

        PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
        if (data == null) return;

        for (int i = 1; i <= kz.hourlyrewards.data.TaskRegistry.size(); i++) {
            int slot = plugin.getTaskManager().getSlot(i);
            TaskState state = data.getTaskState(i);
            String displayTime = plugin.getTaskManager().getDisplayTime(i);
            String prize = plugin.getTaskManager().getPrizeDisplay(i);
            long required = plugin.getTaskManager().getRequiredSeconds(i);
            long current = data.getPlaytimeSeconds();

            ItemStack item = buildTaskItem(i, state, displayTime, prize, required, current, greenTexture, redTexture);
            inv.setItem(slot, item);
        }

        player.openInventory(inv);
    }

    private ItemStack buildTaskItem(int taskId, TaskState state, String displayTime, String prize,
                                    long required, long current, String greenTex, String redTex) {
        switch (state) {
            case LOCKED: {
                String name = "§8§l" + taskId + "§f-§8Тапсырма";
                List<String> lore = Arrays.asList(
                    "§7",
                    "§f" + taskId + "-Тапсырма §7| §c§lЖабық",
                    "§7",
                    "§fМіндет§7: §e" + displayTime + " ойнаңыз",
                    "§7",
                    "§fСыйлық§7: §6§l" + prize,
                    "§7",
                    "§8✖ §7Алдыңғы тапсырманы орындаңыз!"
                );
                return SkullBuilder.createSkull(redTex, name, lore);
            }
            case OPEN: {
                String name = "§a§l" + taskId + "§f-§aTапсырма";
                List<String> lore = Arrays.asList(
                    "§7",
                    "§f" + taskId + "-Тапсырма §7| §a§lАшық",
                    "§7",
                    "§fМіндет§7: §eСерверде §a" + displayTime + " §eойнаңыз",
                    "§7",
                    "§fСыйлық§7: §6§l" + prize,
                    "§7",
                    "§fСіздің уақытыңыз§7: §e" + TimeUtils.formatTime(current) + " §8/ §a" + displayTime,
                    "§7",
                    "§a➜ §7Тапсырманы орындаңыз..."
                );
                return SkullBuilder.createSkull(greenTex, name, lore);
            }
            case READY: {
                String name = "§6§l✦ §f§aTапсырма §l" + taskId + " §8- §6§lАЛЫҢЫЗ!";
                List<String> lore = Arrays.asList(
                    "§7",
                    "§6§l✦ §fТапсырма орындалды!",
                    "§7",
                    "§fСыйлық§7: §6§l" + prize,
                    "§7",
                    "§6➜ §fАлу үшін §l§eбасыңыз!"
                );
                return SkullBuilder.createSkull(greenTex, name, lore, true);
            }
            case CLAIMED: {
                String name = "§a§l✔ §f" + taskId + "-Тапсырма §a§l(Алынды)";
                List<String> lore = Arrays.asList(
                    "§7",
                    "§a✔ §fБұл тапсырма орындалды!",
                    "§7",
                    "§fСыйлық§7: §6§l" + prize + " §a§l(Алынды)",
                    "§7",
                    "§8Бұл тапсырма аяқталды."
                );
                return SkullBuilder.createSkull(greenTex, name, lore);
            }
            default:
                return new ItemStack(Material.AIR);
        }
    }

    public void refresh(Player player) {
        if (player.getOpenInventory() == null) return;
        String title = ColorUtils.color(GuiSettings.TITLE);
        if (!player.getOpenInventory().getTitle().equals(title)) return;
        open(player);
    }
}